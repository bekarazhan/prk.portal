﻿using System;
namespace asd.Models
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
