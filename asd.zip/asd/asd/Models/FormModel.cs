﻿using System;
namespace asd.Models
{
    public class FormModel
    {
		public string FirstName {get; set; }
		public string LastName { get; set; }
		public string Email { get; set; }
        
    }
}
